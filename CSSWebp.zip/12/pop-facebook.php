.navbar-fb {
	background: #3b5998;
	width: 100%;
	height: 40px;
	padding: 8px;	
	border-top-left-radius: 5px;
	border-top-right-radius: 5px;
	box-sizing: border-box;
    -webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
}
.navbar-fb img {
    width: 40px;
    float:left;
    color:white;
    display: block;
    margin-top:-8px;
    margin-left:-6px;
    margin-right:-20px;
}
.navbar-fb-text {
    color: #fff;
	font-size: 15px;
	font-family: Roboto;
	text-align: center;
	margin-top:2px;
	margin-left:-18px;
}
.navbar-alert-fb {
	display: none;    
    position: relative;
    left:0px;
    top:3px;
    width: 321.5px;
    padding: 5px;
    background: #FFECE8;
    border: 2px solid #E76847;
    color:#000;
    font-size: 13px;
    font-family: system-ui;
    float:center;
    text-align: left;
    margin-left: auto;
    margin-right: auto;
}
.content-box-fb {    
    width: 300px;
    height: auto;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.content-box-fb img {
    width: 57px;
	border-radius: 12px;
    margin-top: 28px;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.txt-login-fb {
    width: 270px;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 17px;
    padding: 5px;
    color: #5D5E62;
    font-size: 14px;
    font-family: Roboto;
    text-align: center;
    display: block;
}
.txt-login-alert {
    width: 270px;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 5px;
    padding: 8px;
    color: #818286;
    font-size: 10px;
    font-family: Roboto;
    text-align: center;
    display: block;
}
.form-group-fb {
	width: 100%;
	height: auto;
}
.form-group-fb input {
	background: #fff;
	width: 100%;
	height: auto;
	margin-left: -1px;
	padding: 12px;
	color: #000;
	font-size: 14px;
	font-weight: 400;
	font-family: Roboto, sans-serif;
	border: 1px solid #bdbebf;
	cursor: pointer;
	outline: none;
}
.form-group-fb input:nth-child(1) {
	border-top-left-radius: 4px;
	border-top-right-radius: 4px;
}
.form-group-fb input:nth-last-child(1) {
	border-top: 0px;
	border-bottom-left-radius: 4px;
	border-bottom-right-radius: 4px;
}
.form-group-fb input::placeholder {
	color: #767676 !important;
}
.form-group-fb .login-form-shid {
	width: 70px;
	height: auto;
	margin-left: 70.5%;
	margin-top: 1%;
	padding: 11px;
	color: #1778f2;
	font-size: 12px;
	font-family: Roboto;
	text-align: center;
	text-transform: uppercase;
	border-top-right-radius: 4px;
	border-bottom-right-radius: 4px;
	position: absolute;
	z-index: 9999999;
	cursor: pointer;
}
.btn-login-fb {
	background: #3577E5;
	width: 100%;
	height: auto;
	margin-top: 10px;
	margin-left: -1px;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 10px;
	color: #fff;
	font-size: 14px;
	font-family: Roboto;
	font-weight: bold;
	text-align: center;
	text-shadow: 1px 0px rgba(0, 0, 0, 0.3);
	border: 1px solid #3578e5;
	border-radius: 5px;
	box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.1);
	outline: none;
	display: block;
}
.txt-create-account {
    width: 100%;
    height: auto;
    padding: 5px;
    color: #3b5998;
    font-size: 13.5px;
    font-family: Roboto;
    text-align: center;
}
.txt-not-now {
    width: 100%;
    height: auto;
    padding: 5px;
    color: #3b5998;
    font-size: 13.5px;
    font-family: Roboto;
    text-align: center;
}
.txt-forgotten-password {
    width: 100%;
    height: auto;
    margin-bottom: 30px;
    padding: 5px;
    color: #7596c8;
    font-size: 13.5px;
    font-family: Roboto;
    text-align: center;
}
.txt-footer {
    width: 100%;
    height: auto;
    margin-top: 30px;
    margin-bottom: 30px;
    margin-left: auto;
    margin-right: auto;
    padding: 0px;
    color: #848586;
    font-size: 12px;
    font-family: Roboto;
    text-align: left;
}
.txt-footer a {    
    color: #4E6EA9;    
}
.txt-footers {
    width: 100%;
    height: auto;
    padding-bottom: 30px;
    padding: 0px;
    margin-left: auto;
    margin-right: auto;
    color: #848586;
    font-size: 11px;
    font-family: Roboto;
    text-align: center;
}
.txt-footers a {    
    color: #7B93B5;    
}
.language-box {
    width: 100%;
    height: auto;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.language-name {
    width: 40%;
    height: auto;
    margin: 5px;
    margin-bottom: 0px;
    color: #3b5998;
    font-size: 12px;
    font-family: Roboto;
    text-align: center;
    display: inline-block;
}
.language-name i {
    width: 23px;
    padding: 4px;
    color: #90949c;
    border: 1px solid #3b5998;
    border-radius: 3px;
}
.language-name-active {
    color: #90949c;
    font-weight: bold;
}
.copyright {
    width: 40%;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    color: #90949c;
    font-size: 12px;
    font-family: Roboto;
    text-align: center;
    display: block;
}
.login-form-shid img {
    width: 22px;
	margin-top: -1px;
	float:right;
	margin-right: 3px;
}
?>