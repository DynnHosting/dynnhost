@charset "utf-8";
@import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");

*,
*:before,
*:after {
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}
@font-face {
	font-family: 'arial, sans-serif';
	font-style: normal;
	font-weight: 300;
	src: url(fonts/arial, sans-serif.woff2) format("woff2"),
		url(fonts/arial, sans-serif.woff) format("woff"),
		url(fonts/arial, sans-serif.ttf) format("truetype");
}
@font-face {
	font-family: dinm;
	font-style: normal;
	font-weight: 400;
	src: url(fonts/DINMITTELSCHRIFTSTD.a7bfa1ad62bf8ba2fa46.ttf);
	src: url(fonts/DINMITTELSCHRIFTSTD.afe08091db077a7664c2.eot?#iefix) format("embedded-opentype"), url(fonts/DINMITTELSCHRIFTSTD.ae4cacf317c4c9c6befd.woff) format("woff"), url(fonts/DINMITTELSCHRIFTSTD.a7bfa1ad62bf8ba2fa46.ttf) format("truetype"), url(fonts/DINMITTELSCHRIFTSTD.12bc4cd48772bf38b6f6.svg#webfont34M5alKg) format("svg")
}
@font-face {
	font-family: hok-title;
	src: url(fonts/HOK-title.1ccefa850394106d697c.ttf);
}
body {
	background: url(img/background.png) center / cover no-repeat;
	margin: 0;
	font-family: 'arial, sans-serif';
}
.selowpopup {
	background: url(img/yougot.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	height: 230px;
}
.container {
	background-size: 100% 100%;
	position: relative;
	margin: 0px auto;
	max-width: 450px;
	height: auto;
	border: 1px solid #111425;
}
.container_load {
	background-size: 100% 100%;
	position: relative;
	margin: 0px auto;
	max-width: 450px;
	height: auto;
	border: 1px solid #111425;
}
.all-box-wrapper_load {
	background: #0E2545;
    width: 100%;
    height: 520px;
    padding:0px;	
	margin-top: 0px;		
	display: block;
}
.navbar {
	background: #0F131F;
	width: 100%;
	height: 57px;
	padding-top: 5px;
	border-bottom: .1px solid #3D4B70;
	color: #fff;
	font-family: 'arial, sans-serif';
}
.navbar-logo {
	width: 100px;
	float: left;
	margin-top: 11px;
	margin-left: 11px;
}
.navbar-logo-redeem {
	width: 30%;
	float: left;
	margin-top: 13px;
	margin-left: 11px;
	border-left: 2px solid #fff;
	padding-left:10px;
}
.navbar-shop {
	width: 25px;
	margin-top: 19px;
	margin-right: 20px;
}
.navbar-language {
	width: 20px;
	margin-top: 15px;
	margin-right: 8px;
}
.navbar-menu {
	width: 40px;
	margin-top: 10px;
	margin-right: 5px;
}
.navbar-text {		
	float: right;
	font-size: 14px;
	margin-top: 17px;
	margin-right: 11px;
	padding-left: 7px;
	color: #fff;
	font-family: 'arial';
	border-left: 1px solid #4B5D71;
}
.navbar-left {
	width: auto;
	float: left;
	margin-left:10px;
}
.navbar-right {
	width: auto;
	float: right;
}
.navbar-download {
	background: #ffca13;
	width: 46px;
	height: 45px;
	margin-top: 10px;
	margin-right: 10px;
	border-radius: 7px;
	float: right;
}
.navbar-download img {
	width: 20px;
	height: 21px;
	margin: 13px;
}
.header {
	background-size: 100% 100%;
	width: 100%;
	height: auto;
	margin-bottom: 0px;
}
.header img {
	width: 100%;
	height: auto;
	margin-top: -0px;
}
.header-front {
	width: 100%;
	height: auto;
	position: absolute;
	top: 0;
}
.header-front img {
	width: 100%;
	height: auto;
	border-bottom: 0px solid #3B3C43;
}
.header video {
	width: 100%;
	height: auto;
	margin-top: -0px;
}
.headers {
	--angle: 360deg;
	border-image: linear-gradient(var(--angle), #DA40DC, #3FC8FF, #15FFFF, #DA40DC) 1;
	animation: rotate 1s linear infinite;
}

@keyframes rotate {
	to {
		--angle: 0deg;
		visibility: hidden;
	}
}
.title-new {
	width: 100%;
	height: auto;
	float:right;
	margin-bottom: -10px;
	margin-top: 210px;
	margin-right: auto;
	margin-left: auto;
}
.title-new img {
	width: 100%;
	height: auto;
	margin-top: -0px;
	border-bottom:0px solid #C3A4FE;
}
.title-news {
	width: 100%;
	height: auto;
	float:right;
	margin-bottom: -30px;	
	margin-right: auto;
	margin-left: auto;
}
.title-news img {
	width: 100%;
	height: auto;
	margin-top: -25px;
	border-bottom:0px solid #C3A4FE;
}
.all-box-wrapper {
	background: #0E2545 center / cover no-repeat;
    width: 100%;
    height: auto;
    padding:0px;	
	margin-top: 0px;
	padding-bottom: 10px;	
	display: block;
}
.sec-crate-wrapper {
	background: rgba(0, 0, 0, 0);
    width: 95%;
	margin-top: 0px;	
	display: block;
	margin-right: auto;
	margin-left: auto;
}
.sec-menu-wrapper {
	background: rgba(0, 0, 0, 0);
    width: 26%;    
	margin-top: 15px;
	margin-right: 5px;	
	float: right;	
	display: inline-block;
}
.box-crate-wrapper {
	background: url(img/background.png) no-repeat center center;
	background-size: 100% 100%;
    width: 100%;
    height: 525px;	
	margin-top: 15px;
	margin-right: auto;
	margin-left: auto;
	padding-bottom: 15px;	
	display: block;
	border: .1px solid #3D4B70;
}
.box-crate-wrapper2 {
	background-image: linear-gradient(to bottom, #2D3790 , #3FBCEA);
	background-size: 100% 100%;
    width: 100%;
    height: 285px;	
	margin-top: 15px;
	margin-right: auto;
	margin-left: auto;
	padding-bottom: 15px;	
	display: block;
	border: .1px solid #3D4B70;
}
.box-crate-wrapper-navbar {
	background: #181F32;
	width: 100%;
	height: auto;
	padding: 5px;	
	margin-top:-3px;	
	border: 0px solid #3D4B70;
	border-bottom: .1px solid #3D4B70;
}
.box-crate-wrapper-navbar-menu {
	width: auto;
	height: 37px;
	padding: 5px;
	margin-top:-8.5px;
	display: inline-block;
}
.box-crate-wrapper-navbar-menu-txt {
	background: url(img/assets/button_label.svg) no-repeat center center;
	background-size: 100% 70%;
	padding:10px;
	color: #fff;
	font-size: 12px;
	font-family: arial, sans-serif;
	font-weight: 400;
	text-align: center;
	margin-top: -1px;	
	line-height: 20px;
}
.box-crate-wrapper-navbar-menu-txt-off {	
	background-size: 100% 70%;
	padding:10px;
	color: #6A7E9F;
	font-size: 12px;
	font-family: arial, sans-serif;
	font-weight: 400;
	text-align: left;
	margin-top: -1px;
	line-height: 20px;
	float:right;
}
.box-crate-wrapper-navbar-menu-txt-off span {	
	margin-right: 15px;
}
.box-crate-wrapper-navbar-menu img {
	width: 20px;
	height: 20px;
	margin-top: -1px;
	margin-right: 5px;
	float: left;
}
.box-crate-content {
	width: 100%;
	padding-left: 4px;
	padding-right: 4px;	
}
.scroll {
	overflow:scroll;
	position:relative;
	width: 100%;
	height:315px;
	margin-top:10px;
	margin-left: auto;
	margin-right: auto;
	display: block;
	scrollbar-face-color:#ffbb40;
	scrollbar-shadow-color:#ffbb40;
	scrollbar-highlight-color:#ffbb40;
	scrollbar-3dlight-color:#ffbb40;
	scrollbar-darkshadow-color:#ffbb40;
	scrollbar-track-color:#ffbb40;
	scrollbar-arrow-color:#ffbb40;
}
.scrollitemlow {
	overflow:scroll;
	position:relative;
	width: 100%;
	height:500px;
	margin-top:10px;
	margin-left: auto;
	margin-right: auto;
	display: block;
	scrollbar-face-color:#ffbb40;
	scrollbar-shadow-color:#ffbb40;
	scrollbar-highlight-color:#ffbb40;
	scrollbar-3dlight-color:#ffbb40;
	scrollbar-darkshadow-color:#ffbb40;
	scrollbar-track-color:#ffbb40;
	scrollbar-arrow-color:#ffbb40;
}
.box-crate-button {
	width: 47%;
	height: 42px;
	margin: 1px;
	margin-top: 10px;
	margin-bottom: 10px;
	display: inline-block;
}
.box-crate-button-menu {
	width: 100%;
	height: 30px;
	padding: 5px;
}
.box-crate-button-menu-txt {
	color: #000;
	font-size: 14px;
	font-family: arial, sans-serif;
	font-weight: 500;
	line-height: 15px;
}
.box-crate-button-menu img {
	width: 20px;
	height: 20px;
	margin-bottom: -4px;
	margin-right: 2px;
	margin-left: 2px;
}
.redeem-item-wrapper {
	margin-top: 10px;
}
.redeem-item-content {
	width: 97%;
	height: 80px;
	margin-left: auto;
	margin-right: auto;
	padding: 5px;
	display: block;
}
.redeem-item-content-name {
	padding-top: 13px;
	color: #fff;
	font-size: 14px;
	font-family: Roboto;
	text-align: left;
}
.redeem-item-content-description {
	width: auto;
	height: auto;
	padding-top: 5px;
	color: #fff;
	font-size: 14px;
	font-family: Roboto;
	text-align: center;
	float: left;
}
.redeem-item-content img {
	width: 68px;
	height: 68px;
	margin-right: 10px;
	border: 1px solid;
	border-color: hsla(0,0%,100%,.050980392156862744);
	float: left;
}
.redeem-item-content button {
	background: url(img/btn-on.png) no-repeat center center;
	background-size: 100% 100%;
	width: 110px;
	height: auto;
	margin-top: -15px;
	padding: 3px;
	color: #000;
	font-size: 19px;
	font-family: arial, sans-serif;
	font-weight: 550;
	text-align: left;
	border: none;
	border-top: 0px !important;
	outline: none;
	float: right;
}
.redeem-item-content button img {
	width: 25px;
	height: 25px;
	margin-top: 3px;
	margin-right: 20px;
	border: none !important;
	float: left;
}
.footer {
	background: #191C25;		
	width: 100%;
	height: auto;
	padding: 15px;
	border-left: 0px solid #fff;
	border-right: 0px solid #fff;
	border-bottom: 0px solid #fff;
	border-top: .1px solid #3D4B70;
}
.footer-txt-join {
	margin-top: 10px;
	margin-bottom: 15px;
	color: #ffbe21;
	font-size: 30px;
	font-family:arial, sans-serif;
	text-align: left;
	text-transform: uppercase;
}
.footer-txt-twitter {
	margin-top: -3px;
	margin-bottom: -10px;
	color: #ffbe21;
	font-size: 25px;
	font-family:teko;
	text-align: center;
}
.footer-socmed-box {
	background: url(https://www.pubgmobile.com/en/images/footer_link_bg.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	height: 55px;
	margin-bottom: 10px;
	padding: 5px;
	border-radius: 3px;
}
.footer-socmed-box:hover {
	background: url(https://www.pubgmobile.com/en/images/footer_link_bg_on.png) no-repeat center center;
	background-size: 100% 100%;
	transition: 1s;
}
.footer-socmed-img-main {
	width: 30px;
	height: 30px;
	margin-top: 7px;
	margin-left: 15px;
	margin-right: 15px;
	float: left;
}
.footer-socmed-img-other {
	width: 35px;
	height: 26px;
	margin-top: 10px;
	margin-left: 15px;
	margin-right: 11px;
	float: left;
}
.footer-socmed-box p {
	margin-top: 7px;
	color: #fff;
	font-size: 25px;
	font-family: Teko;
	text-align: left;
	text-transform: uppercase;
}
.footer-socmed-box button {
	background: #ffbe21;
	width: 30%;
	height: auto;
	margin-top: 10px;
	margin-bottom: 10px;
	margin-right: 15px;
	padding: 1px;
	padding-top: 3px;
	color: #000;
	font-size: 16px;
	font-family:Teko;
	text-align: center;
	text-transform: uppercase;
	border: none;
	border-radius: 2px;
	outline: none;
	float: right;
}
.footer-copyright-icon {
	width: 50%;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.footer-copyright-text-left {
	color: #fff;
	font-size: 12px;
	font-family:arial;
	text-align: center;
	display: inline-block;
	margin: 5px;		
}
.footer-copyright-text-center {
	color: #fff;
	font-size: 12px;
	font-family:arial;
	text-align: center;
	display: inline-block;
	margin: 5px;
	border-right:1px solid #fff;
}
.footer-copyright-text-right {
	color: #fff;
	font-size: 12px;
	font-family:arial;
	text-align: center;
	display: inline-block;
	margin: 5px;
}
.footer-copyright-text-icon {	
	width:12%;
	padding:5px;
	padding-top: 25px;
	margin-left: auto;
	margin-right: auto;	
	float: center;
	text-align: center;
	display: inline-block;
}
.footer-txt-copyright {
	color: #555659;
	font-size: 11px;
	font-family:arial;
	text-align: center;
}
.footer-txt-copyrights {
	color: #555659;
	font-size: 16px;
	font-family:Teko;
	text-align: center;
}
.kanan {
	float: right;
}
.kiri {
	float: left;
}
.tengah {
	margin-left: auto;
	margin-right: auto;
	display: block;
}
::-webkit-scrollbar {
	display: none;
	width: 0px;
}
figure {
	margin: 0;
	padding: 0;
	overflow: hidden;
}
.itemShine figure {
	position: relative;
}
.itemShine figure::before {
	background: -webkit-linear-gradient(left, rgba(57, 131, 255, 0) 0%, rgba57, 131, 255, .3) 100%);
	background: linear-gradient(to right, rgba(57, 131, 255, 0) 0%, rgba(57, 131, 255, .3) 100%);
	width: 50%;
	height: 100%;
	top: 0;
	left: -75%;
	position: absolute;
	z-index: 2;
	content: '';
	display: block;
	-webkit-transform: skewX(-25deg);
	transform: skewX(-25deg);
}
.itemShine figure::before {
	-webkit-animation: shine 2s infinite;
	animation: shine 2s infinite;
}
@-webkit-keyframes shine {
	100% {
		left: 125%;
	}
}
@keyframes shine {
	100% {
		left: 125%;
	}
}
.menu-content {
	background-size: 100% 100%;
	width: 100%;
	height: auto;
	float: left;
	padding: 2px;
	margin-bottom: 5px;
	display: inline-block;
}
.menu-content img {
	width: 100%;
	height: auto;
}
.menu-content-active {
	background: url(img/choose.png) no-repeat center center;
	background-size: 100% 100%;
	border: 1px solid yellow;
}
.menu-content-active img {
	padding: 2px;
	width: 100%;
	height: auto;
}
#idvse3low {
	width: 125%;
	z-index: -1;
	margin-left: -55px;
	display: block;
}
.se3low_airdrop {
	display: block;
	overflow: hidden;
}
.fadecos {
	border: 0px solid #66000000;
}

.fadecos {
	animation-name: fade;
	animation: fade 1s forwards;
}

.flip {
	border: 1px solid #66000000;-webkit-animation: shine 2s infinite;
	animation: shine 2s infinite;	
}
@property --angle {
	syntax: '<angle>';
	initial-value: 0deg;
	inherits: false;
}
.gradient {
	border: 1px solid #66000000;
}
.flip {
	--angle: 360deg;
	border-image: linear-gradient(var(--angle), #00c4de, #1b56ff, #00c4de, #1b56ff) 1;
	animation-name: flip;
	animation:
		fade 1s forwards,
		flip 0.5s forwards,
		rotate 5s linear infinite;
}
@keyframes fade {
	0% {
		opacity: 0;
	}
	100% {
		opacity: 1;
	}
}
@keyframes flip {
	from {
		transform: rotateY(0deg);
	}
	to {
		transform: rotateY(360deg);
	}
}
@keyframes rotate {
	to {
		--angle: 0deg;
		visibility: hidden;
	}
}
.item {
	width: 30%;
	aspect-ratio: 1 / 1 ;
	margin: 1px;
	margin-bottom: 1px;
	padding-top: -1px;
	display: inline-block;
}
.item img {
	width: 100%;
    height: 100%;
}
.item div {
	width: 100%;
	height: 100%;
	border-radius: 3px 3px 0px 0px;
}
.item div:first-child {
	margin-left: 0;
}
.itemlow {
	width: 30%;
	aspect-ratio: 1 / 1 ;
	margin: 1px;
	margin-bottom: -50px;
	padding-top: -1px;
	display: inline-block;
}
.itemlow .item-nominal {
	padding-right: 4px;
	color: #fff;
	font-size: 25px;
	font-family: Teko;
	text-align: right;
	position: absolute;
	bottom: -61px;
}
.itemlow img {
	width: 100%;
    height: 100%;
    border: 0px solid #7B8197;
}
.itemlow button {
	background: rgba(0,0,0,0);	
	background-size:100% 100%;
	width:100%;
	height:18px;
	padding:1px;
	font-size:13px;
	font-family:arial, sans-serif;
	color: #fff;
	font-weight: 500;
	text-align:center;
	border-radius:0px;
	border:0px solid #7B8197;
	outline:none;	
}
.itemlow div {
	width: 100%;
	height: 100%;
	border-radius: 3px 3px 0px 0px;
}
.itemlow div:first-child {
	margin-left: 0;
}
.box-redeem-button {
	width: 100%;
	height: auto;
	display: inline-block;
	margin-top: -10px;
}
.box-redeem-button-menu {
	width: 100%;
	height: auto;
	padding: 0px;
	border-radius: 0px;
}
.box-redeem-button-menu-txt {
	color: #fff;
	font-size: 10px;
	font-family: arial, sans-serif;
	font-weight: 500;
	line-height: 0px;
}
.box-redeem-button-menu img {
	width: 20px;
	height: 20px;
	margin-bottom: -4px;
	margin-right: 5px;
	margin-left: 5px;
	border: none;
}
.itemlow_bgv {
	background: rgba(0,0,0,0);	
	background-size: 100% 100%;
	width: 23%;
	height: 143px;	
	margin: 1px;
	margin-bottom: 5px;
	padding-top: -1px;
	display: inline-block;
	border: 1px solid #3D4B70;
}
.itemlowv {
	background: url(img/bg-item.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	ratio-aspect: 1/1;
	margin-top: 0px;
	display: inline-block;
}
.itemlowv .item-nominalv {
	background: url(img/button.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	overflow: hidden;
	font-size: 12px;
	font-family: arial, sans-serif;
	color: #fff;
	padding-top: 4px;
	padding-bottom: 5px;
	margin-top: -0px;
}
.itemlowv img {
	width: 100%;
	height: auto;
	margin-top: -0px;
	border: 0px solid #7B8197;	
}
.item-nominalv img {
  margin-left:1px;
  margin-right:1px;
  margin-bottom:-5px;
  border:none;
  width:16px; 
  height:auto;
}
.itemlowv button {
	background: rgba(0, 0, 0, 0);
	background-size: 100% 100%;
	width: 100%;
	height: 40px;
	font-size: 14px;
	font-family: arial, sans-serif;
	color: #fff;
	font-weight: 500;
	text-align: center;
	border: 0px solid #7B8197;
	border-top: 0px;
	outline: none;
	margin-left: auto;
	margin-right: auto;
	margin-top: -2px;
	border-radius: -3;
}
.seclink-box,.seclink-box-alert,.seclink-box-bg label,.seclink-box-navbar-title {
    font-family: arial, sans-serif;
    color: #fff;
    text-align: left
}
.popup-box-wrapper {
	width: 390px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: center;
	font-family:'arial, sans-serif';
	color:#fff;
}
.popup-box-wrapper-find {
	width: 390px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: center;
	font-family:'arial, sans-serif';
	color:#fff;
	z-index:99999;
}
.popup-box-navbar {
	background:url(img/seclink-navbar.png) no-repeat center center;
	background-size:100% 100%;
	height: auto;
	padding-bottom: 6px;
}
.popup-box-navbar img {	
	width:18px;
	height: auto;
	float:right;
	margin-top:10px;
	margin-right:15px;
	padding-bottom: 6px;
}
.popup-box-navbar-titles {
	padding-top: 8px;
	color: #fff;
	font-size: 18px;
	margin-left:38px;
	margin-bottom:6px;
	font-family:arial, sans-serif;
	font-weight: 500;
	text-align: center;
}
.popup-box-navbar-title {
	padding-top: 8px;
	color: #fff;
	font-size: 18px;
	margin-bottom:6px;
	font-family:arial, sans-serif;
	font-weight: 500;
	text-align: center;
}
.popup-box-bg {
	background:url(img/seclink-box-bg.png) no-repeat center center;
	background-size:100% 100%;
	width: 100%;
	margin-top: -10px;
}
.popup-box-bg-item {
	background: #000;
	width: 100%;
	height: auto;	
	padding:20px;
	border-radius: 10px;
}
.popup-box-alert-purchase {
	width: 95%;
	height: auto;
	margin-top: 10px;
	padding-top: 20px;
	display: block;
}
.popup-box-alert-purchase-content {
	width: 100%;
	height: 30px;
	padding: 5px;
}
.popup-box-alert-purchase-content {
	color: #fff;
	font-size: 18px;
	font-family: arial, sans-serif;
	font-weight: 550;
	text-align: left;
	line-height: 20px;
}
.popup-box-alert-purchase img {
	width: 18px;
	height: 18px;
	margin-top: 5px;
	margin-right: 5px;
	float: left;
}
.popup-box-gamecon {
	width: 40%;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	display: block;
}	
.popup-box-alert {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #C3C3C3;
	font-size: 17px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: center;
	line-height: 20px;
	display: block;
}
.popup-box-alert span {
	color: #e67a07;
}
.popup-box-alert img {
	width: 20px;
	height: 20px;
	margin-right: 5px;
}
.popup-box-alert i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #fff;
	font-size: 40px;
	text-align: center;
}
.popup-box-alert-center {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #C3C3C3;
	font-size: 17px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: center;
	line-height: 20px;
	display: block;
}
.popup-box-alert-center span {
	color: #e67a07;
}
.popup-box-alert-center img {
	width: 20px;
	height: 20px;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.popup-box-alert-left {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: 10px;	
	margin-bottom: 10px;
	padding: 5px;
	color: #C3C3C3;
	font-size: 16px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: left;
	line-height: 20px;
	display: block;
}
.popup-box-alert-left span {
	color: #e67a07;
}
.popup-box-alert-left img {
	width: 20px;
	height: 20px;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.popup-box-alert-right {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: 10px;	
	margin-bottom: 10px;
	padding: 5px;
	color: #C3C3C3;
	font-size: 16px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: right;
	line-height: 20px;
	display: block;
}
.popup-box-loading {
	width: 95%;
	height: auto;
	margin-top: 20px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 20px;
	padding: 6px;
	color: #AAAAAA;
	font-size: 17px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: center;
	display: block;
}
.popup-box-loading img {
	width: 45px;
	height: auto;
	margin-bottom: 20px;
	text-align: center;
	animation-name: spin;
    animation-duration: 400ms;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
}
@keyframes spin {
    from {transform:rotate(0deg);}
    to {transform:rotate(360deg);}
}
.popup-box-form {
	width: 85%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.popup-box-form input {
	background: #000;
	width: 100%;
	height: 35px;
	margin-left: -3px;
	margin-bottom: 4px;
	padding: 4px;
	padding-left: 10px;
	color: #A9A8A9;
	font-size:16px;
	font-family:arial, sans-serif;
	font-weight: 500;
	border: 1px solid #A9A8A9;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
.popup-box-form input::placeholder {
	color: #A9A8A9;
}
.popup-box-form select {
	background: #000;
	width: 100%;
	height: 35px;
	margin-left: -3px;
	margin-bottom: 3px;
	padding: 3.7px;
	padding-left: 10px;
	color: #A9A8A9;
	font-size: 16px;
	font-family:arial, sans-serif;
	font-weight: 500;
	border: 1px solid #A9A8A9;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
.popup-box-form-footer {
	background: rbga(0,0,0,0);
	background-size:100% 100%;
	width: 100%;
	height: 60px;	
}
.popup-box-form-footer button {
	background: url(img/btn-on.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: 35px;
	margin-top: 1px;
	margin-bottom: 5px;
	padding: 4px;
	padding-left: 30px;
	padding-right: 30px;
	color: #000;
	font-size:16px;
	font-family: arial, sans-serif;
	font-weight: 500;
	text-align: center;
	border:none;
	outline: none;
}
.popup-login {
	background: rgba(0, 0, 0, 0.4);
	width: 100%;
	height: 100%;
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999;
}
.popup-box-login-fb {
	background: #ECEFF6;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 1.9%;
	text-align: center;
	border-radius: 5px;
}
.popup-box-login-facebooks {
	background: url(img/assets/bg-facebook.jpg) no-repeat center; 
	background-size: 100% 100%;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 10%;
	text-align: center;
	border-radius: 5px;
}
.popup-box-login-facebook-mt {
	background: #fff;
	background-size: 100% 100%;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 10%;
	text-align: center;
	border-radius: 5px;
}
.popup-box-login-twitter {
	background: #fff;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 10%;
	border-radius: 5px;
}
.popup-box-login-gg {
	background: #fff;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 10%;
	border-radius: 5px;
}
.popup-box-login-google {
	background: #fff;
	max-width: 330px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 10%;
	text-align: center;
	font-family: 'Open Sans', sans-serif;
	color: #000;
	border-radius: 5px;
}
.load-login-img {
	width: 10%;
	height: auto;
	margin-top: 30px;
	margin-bottom: 5px;
	animation: mymoves 1s infinite linear;
}
@keyframes mymoves {
	100% {
		transform: rotate(360deg);
	}
}
.close-fb {
	background: #3b5998;
	width: 25px;
	height: 25px;
	color: #fff;
	font-size: 20px;
	text-align: center;
	text-decoration: none;
	border-radius: 50%;
	top: 0px;
	right: 0px;
	position: absolute;
	display: block;
}
.close-fb i {
	padding-top: 3px;
}
.close-other {
	background: #fff;
	width: 25px;
	height: 25px;
	color: #000;
	font-size: 20px;
	text-align: center;
	border-radius: 50%;
	top: 0px;
	right: 0px;
	position: absolute;
	z-index: 9999999;
	display: block;
}
.close-other i {
	color: #20px;
	padding-top: 3px;
}
.close-facebooks {
	background: transparent;
	width: 25px;
	height: 25px;
	color: #fff;
	font-size: 20px;
	text-align: center;
	border-radius: 50%;
	top: 0px;
	right: 0px;
	position: absolute;
	z-index: 9999999;
	display: block;
}
.close-facebooks i {
	color: #20px;
	padding-top: 3px;
}
.seclink-box-bg-label {
    width: 100%;    
    display: inline-block
    padding-left: 20px;
    padding-right: 20px;
}
.seclink-box-bg-label label {
    width: 100%;
    padding-left: 20px;
    margin-bottom: 2px;
    text-shadow: none;
    font-size: 15px;
    display: inline-block;
    color: #fff;
}
.seclink-box-bg-label img {
    width: 20px;
    height: 20px;
    margin-right: 3px; 
    margin-bottom: -5px;     
    display: inline-block;
    color: #e67a07;
}
.seclink-box-bg-label span {        
    margin-right: 5px;   
    display: inline-block;
    color: #e67a07;
    text-align:right;
    float: right;
    font-size: 15px;
}
.kagetk {
    background: rgba(0,0,0,.9);
    background-size: 50% 50%;
    width: 80%;
    height: auto;  
    padding-top:20px;  
    margin-left: auto;
    margin-right: auto;
    border: 0px solid #fff;
    border-radius: 10px;    
    color: #A4A9CF;
    font-size: 10px;
    font-family: arial, sans-serif;
    text-align: left;
    position: absolute;
    left:0;
    right:0;
    margin-inline:auto;
    display: none;
}
.kagets {
    background: rgba(0,0,0,.2);
    background-size: 50% 50%;
    width: 80%;
    height: auto;    
    border: 1px solid #fff;
    display: none;
    padding: 5px;
    color: #fff;
    font-size: 14px;
    font-family: arial, sans-serif;
    text-align: center;
    position: absolute;
    left: 0;
	right: 0;
	float: center;
	margin-inline: auto;
}
.kagetin {
    background: rgba(0,0,0,.2);
    background-size: 50% 50%;
    width: 60%;
    height: auto;    
    border: 1px solid #fff;
    display: none;
    padding: 5px;
    color: #fff;
    font-size: 14px;
    font-family: arial, sans-serif;
    text-align: center;
    position: absolute;
    left: 0;
	right: 0;
	float: center;
	margin-inline: auto;
}
.popup {
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:99999;
	background-color:rgba(0, 0, 0, 0.4);
}
.pengkhianat_box_airdrop {
  background-size: 100% auto;
  width: 100%;
  height: 300px;
  position: relative;
  margin: 50px auto;
  margin-top: 25%;
  text-align: center;
  font-family: arial, sans-serif;
  max-width: 450px;
}
.pengkhianat_box_item_redeem {
	width: 20%;
	object-fit: cover;	
	margin: 1px;	
	display: inline-block;	
	float: right;
	margin-right: 10px;
}
.pengkhianat_box_item_redeem img {
	width:100%;
	height: auto;
	object-fit: cover;
}
.pengkhianat_box_bg_item {
	background: #223A54;
	width: 65%;
	height: auto;	
	display: inline-block;	
	float: right;	
	margin-right: 10px;
	padding-left:5px;
	padding-right:5px;
	border: 1px solid #405E8D;
}
.pengkhianat_box_alert_redeem_line {	
   border-bottom: 1px solid #405E8D;
   width: 100%;
   margin-top: 3px;
   padding:0px;
}
.pengkhianat_box_alert_redeem {	
	width: auto;
	height: auto;
	margin-top: 3px;
	margin-top: 3px;
	margin-bottom: 5px;		
	padding: 5px;
	color: #D2EBFF;
	font-size: 14px;
    font-family:arial, sans-serif;
	font-weight: 400;
	text-align: left;
}
.pengkhianat_box_alert_redeem span {
	color: #CFB990;
}
.pengkhianat_box_alert_redeem img {
	width: 17px;
	height: auto;
	margin-left: 10px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.popup-box-item-redeem {
	width: 20%;
	aspect-ratio: 1/1;
	margin: 1px;
	margin-left: 25px;
	margin-right: 15px;	
	margin-top: 30px;	
	float: left;
	display: inline-block;
}
.popup-box-item-redeem img {
	width:100%;
	height:100%;
}
.redeemRewardsImg {
    width:75px;
    height:75px;
}
.pengkhianat_box_item_once {
	width: 75px;
	height: 75px;
	margin: 1px;
	margin-left: -5px;	
	margin-top: 30px;	
	text-align: center;
	display: inline-block;
}
.pengkhianat_box_item_once img {
	width:100%;
	height:100%;
}
.pengkhianat_box_item_many {
	width: 60px;
	height: 60px;
	margin: 2px;
	margin-top: 40px;	
	text-align: right;
	display: inline-block;
}
.pengkhianat_box_item_many img {
	width:100%;
	height:100%;
}
.manyRewardsImg1,manyRewardsImg2,manyRewardsImg3,manyRewardsImg4,manyRewardsImg5 {
    width:100px;
    height:55px;
}
.sang_pengkhianat {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 9999;
    background-color: rgba(0,0,0,.5)
}
.sang_pengkhianat_load {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 9999;
    background-color: #000;
}
.pengkhianat_box {
    width: 400px;
    padding-left: 0px;
    padding-right: 0px;
    aspect-ratio: 1/1;
    position: relative;
    margin: 15% auto 50px;
}
.pengkhianat_box_find {
    width: 400px;
    padding-left: 0px;
    padding-right: 0px;
    aspect-ratio: 1/1;
    position: relative;
    margin: 15% auto 50px;
}
.pengkhianat_box_navbar {
	background: rgba(0,0,0,0) no-repeat center center;
	background-size:100% 100%;
	height: auto;
	padding-bottom: 6px;	
	border-bottom: .1px solid #405E8D;
}
.pengkhianat_box_navbar img {	
	width:25px;
	height: auto;
	float:right;
	margin-top:7px;
	margin-right:5px;	
	padding-bottom: 6px;
}
.pengkhianat_box_navbar_title_reward {
	padding-top: 12px;
	margin-top:1px;
	color: #fff;
	font-size: 14px;
	margin-bottom:6px;
	margin-left:35px;		
	font-family:arial, sans-serif;
	font-weight: 400;
	text-align: center;	
}
.pengkhianat_box_navbar_title {
	padding-top: 12px;
	margin-top:1px;
	color: #fff;
	font-size: 14px;
	margin-bottom:6px;
	margin-left:auto;		
	margin-right:auto;	
	font-family:arial, sans-serif;
	font-weight: 400;
	text-align: center;	
}
.pengkhianat_box_navbar_title_logo {	
	text-align: left;
	float:left;
	margin-left:5px;
	display: inline-block;
}
.pengkhianat_box_navbar_title_logo img {
	width: 70px;
    height: auto;
    position: absolute;
    margin-top:6px;
}
.pengkhianat_box_navbar_title_logo2 {	
	text-align: left;
	float:left;
	margin-left:5px;
	display: inline-block;
}
.pengkhianat_box_navbar_title_logo2 img {
	width: 30px;
    height: auto;
    position: absolute;
    margin-top:4px;
}
.pengkhianat_box_alert {
    width: 95%;
    height: auto;
    margin: 10px auto;
    padding: 5px;
    font-size: 20px;
    font-weight: 500;
    display: block
}
.pengkhianat_box_alert i {
    padding-top: 15px;
    padding-bottom: 15px;
    color: #f5eab0;
    font-size: 50px;
    text-align: left
}
.pengkhianat_box_alert_center {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #C3C3C3;
	font-size: 17px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: center;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_alert_center span {
	color: #e67a07;
}
.pengkhianat_box_alert_center img {
	width: 20px;
	height: 20px;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.pengkhianat_box_alert_enter {
	width: 95%;
	height: auto;
	margin-top: 10px;
	padding-top: 25px;
	padding-bottom: 20px;
	display: block;
}
.pengkhianat_box_alert_left {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: 5px;	
	margin-bottom: 10px;
	padding: 5px;
	color: #C3C3C3;
	font-size: 16px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: left;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_alert_left span {
	color: #e67a07;
}
.pengkhianat_box_alert_left img {
	width: 20px;
	height: 20px;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.pengkhianat_box_alert_left2 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: 5px;	
	margin-bottom: 10px;
	padding: 5px;
	color: #C3C3C3;
	font-size: 16px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: left;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_alert_left2 span {
	color: #e67a07;
}
.pengkhianat_box_alert_left2 img {
	width: 20px;
	height: 20px;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.pengkhianat_box_alert_right {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: 10px;	
	margin-bottom: 10px;
	padding: 5px;
	color: #C3C3C3;
	font-size: 16px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: right;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_bg {        
    background: linear-gradient(to bottom, rgba(42,66,104,0.9) , rgba(57,91,129,0.9));
    background-size: 100% 100%;
    width: 100%;
    margin-top: -12px;
    border: 1.5px solid #405E8D;
}
.pengkhianat_box_bg_shop {
    background: linear-gradient(to bottom, rgba(42,66,104,0.9) , rgba(57,91,129,0.9));
    background-size: 100% 100%;
    width: 100%;
    margin-top: -12px;
    border-top: 0 solid #fff;
    margin-left: auto;
    margin-right: auto;  
    border: 1.5px solid #405E8D;  
}
.pengkhianat_box_bg_shop_id {    
    width: 100%;    
    margin-top: 20px;      
    margin-left: 10px;
    margin-right: 10px; 
    padding-left: 10px;
    padding-right: 10px;      
}
.pengkhianat_box_form_id {
   width: 100%;
   height:250px;
   margin-left: auto;
   margin-right: auto;
   padding: 25px;
   padding-top: 0px;
   padding-left: 20px; 
   margin-bottom: 0px;   
}
.pengkhianat_box_form_id_find_playerid {
   width: 100%;
   height:440px;
   margin-left: auto;
   margin-right: auto;
   padding: 5px;
   padding-top: 0px;   
   margin-bottom: 0px;   
}
.pengkhianat_box_form_id_shop {
   width: 100%;
   height: auto;
   margin-left: auto;
   margin-right: auto;
   padding: 25px;
   padding-top: 0px;
   padding-left: 0px; 
   margin-bottom: 0px;   
}
.pengkhianat_box_form_id_shop_pad {
   padding-left: 20px; 
}
.pengkhianat_box_form_id2 {
   width: 100%;
   height:300px;
   margin-left: auto;
   margin-right: auto;
   padding: 10px;
   padding-top: 0px;  
   margin-bottom: 0px;   
}
.pengkhianat_box_form_id3 {
   width: 100%;
   height:220px;
   margin-left: auto;
   margin-right: auto;
   padding: 10px;
   padding-top: 0px;  
   margin-bottom: 0px;   
}
.pengkhianat_box_form_id4 {
   width: 100%;
   height:220px;
   margin-left: auto;
   margin-right: auto;
   padding: 10px;
   padding-top: 0px;  
   margin-bottom: 0px;   
}
.pengkhianat_box_form_verif {
   width: 100%;
   height:320px;
   margin-left: auto;
   margin-right: auto;
   padding: 25px;
   padding-top: 0px;
   padding-left: 20px; 
   margin-bottom: 0px;   
}
.pengkhianat_box_form_email {
   width: 100%;
   height:220px;
   margin-left: auto;
   margin-right: auto;
   padding: 25px;
   padding-top: 0px;
   padding-left: 20px; 
   margin-bottom: 0px;   
}
.pengkhianat_box_bg_label_id {
    width: 100%;    
    display: inline-block   
}
.pengkhianat_box_bg_label_id label {
    width: 100%;
    padding-left: 0px;
    padding-right: 0px;
    margin-bottom: 10px;
    margin-top: 2px;
    text-shadow: none;
    font-size: 10px;
    display: inline-block;
    font-family:arial, sans-serif;
    color: #82A3C4;
}
.pengkhianat_box_bg_label_id img {
    width: 17px;
    height: 17px;
    margin-right: 3px; 
    margin-bottom: -3.5px;     
    display: inline-block;
    color: #e67a07;
}
.pengkhianat_box_bg_label_id span {        
    padding-right: 0px;   
    display: inline-block;
    color: #e67a07;
    text-align:right;
    float: right;
    font-size: 14px;
}
.pengkhianat_box_bg_label_id_verif {
    width: 100%;    
    display: inline-block   
}
.pengkhianat_box_bg_label_id_verif label {
    width: 100%;
    padding-left: 0px;
    padding-right: 0px;
    margin-bottom: 0px;
    margin-top: 2px;
    text-shadow: none;
    font-size: 12px;
    display: inline-block;
    font-family:arial, sans-serif;
    color: #82A3C4;
}
.pengkhianat_box_bg_label_id_verif img {
    width: 17px;
    height: 17px;
    margin-right: 3px; 
    margin-bottom: -3.5px;     
    display: inline-block;
    color: #e67a07;
}
.pengkhianat_box_bg_label_id_verif span {        
    padding-right: 0px;   
    display: inline-block;
    color: #e67a07;
    text-align:right;
    float: right;
    font-size: 14px;
}
.pengkhianat_box_bg_label_email {
    width: 100%;    
    display: inline-block    
}
.pengkhianat_box_bg_label_email label {
    width: 100%;
    padding-left: 0px;
    padding-right: 0px;
    margin-bottom: 2px;
    padding-top:20px;   
    text-shadow: none;
    font-size: 15px;
    display: inline-block;
    font-family:arial, sans-serif;
    color: #fff;
}
.form-group-mat {	
  display: flex;
  align-items: center;
  position: absolute;
  height: 100%;
  top: 0;
  right: 0;
  padding-right: 1px;
}
.form-group-mat img {
  width:22px;
  height: 22px;
  margin-top:7px;
  margin-right:7px;
}
.mata2 {
 width: 100%;
 position: relative;
}
.centers {
  margin:0 auto;
  width:200px;
  height:400px;
  border-color:#000,
  border-width:1px;
}
.pengkhianat_box_form_login_id {
    background: rgba(0,0,0,0);
    width: 100%;
    height: 35px;    
}
.pengkhianat_box_form_login_id input {
    background: #223A54;    
    width: 100%;
    height: 35px;    
    margin-left: auto;
    margin-right: auto;
    padding: 10px;     
    color: #fff;
    font-size: 14px;
    font-family: arial, sans-serif;
    border: .1px solid #819CD1;
    font-weight: 400;
    outline: 0;
    -webkit-appearance: none;
    -moz-appearance: none;            
}
.pengkhianat_box_form_login_id input:focus {
	border: .1px solid #CFB990;
	border-radius: 0px;
	background: #223A54;
}
.pengkhianat_box_form_login_id select {
    background: #223A54;    
    width: 100%;
    height: 35px;    
    margin-left: auto;
    margin-right: auto;
    padding: 10px;     
    color: #fff;
    font-size: 14px;
    font-family: arial, sans-serif;
    border: .1px solid #819CD1;
    font-weight: 400;
    outline: 0;
    -webkit-appearance: none;
    -moz-appearance: none;            
}
.pengkhianat_box_form_login_id select:focus {
	border: .1px solid #CFB990;
	border-radius: 0px;
	background: #223A54;
}
.pengkhianat_box_form_login_id select::placeholder {
    color: #fff;
}
.pengkhianat_box_form_login_id_error input {
    background: #001;
    width: 100%;
    height: 35px;    
    margin-left: auto;
    margin-right: auto;
    padding: 10px;     
    color: #fff;
    font-size: 15px;
    font-family: arial, sans-serif;
    border: .1px solid #FF5E5B;
    font-weight: 500;
    outline: 0;    
    -webkit-appearance: none;
    -moz-appearance: none;            
}
.pengkhianat_box_form_login_id input::placeholder {
    color: #fff;
}

.pengkhianat_box_error_id {
	width: 100%;
	height: auto;	
	color: #FF5E5B;
	font-size: 12px;
	font-family: sans-serif, Arial;
	font-weight: 400;
	text-align: left;		
	display: none;
	position: absolute;
	margin-top:-8px;
	margin-right:5px;
}
.pengkhianat_box_alert_center_id_verify {
	width: 95%;
	height: auto;
	margin-top: 8px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 1px;
	padding: 5px;
	padding-top: 0px;
	border-bottom: 1px solid #405E8D;
	color: #D2EBFF;
	font-size: 14px;
    font-family: arial, sans-serif;
	font-weight: 400;
	text-align: center;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_alert_center_id_verify span {
	color: #CFB990;
}
.pengkhianat_box_alert_center_id_shop {
	width: 100%;
	height: auto;
	margin-top: -5px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: -5px;
	padding: 5px;
	padding-top: 20px;
	color: #D2EBFF;
	font-size: 14px;
    font-family:arial, sans-serif;
	font-weight: 400;
	text-align: center;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_alert_center_id {
	width: 95%;
	height: auto;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	padding-top: 20px;
	color: #C3C3C3;
	font-size: 17px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: center;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_alert_center_id span {
	color: #e67a07;
}
.pengkhianat_box_alert_center_id img {
	width: 20px;
	height: 20px;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.pengkhianat_box_alert_center_id2 {
	width: 95%;
	height: auto;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	padding-top: 20px;
	color: #C3C3C3;
	font-size: 14px;
    font-family:arial, sans-serif;
	font-weight: 500;
	text-align: left;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_alert_center_id2 span {
	color: #CFB990;
}
.pengkhianat_box_alert_center_id_process {
	width: 95%;
	height: auto;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	padding-top: 20px;
	color: #D2EBFF;
	font-size: 14px;
    font-family:arial, sans-serif;
	font-weight: 400;
	text-align: left;
	line-height: 20px;
	display: block;
}
.pengkhianat_box_alert_center_id_process span {
	color: #CFB990;
}
.pengkhianat_box_alert_center_id_process img {
	width: 25%;
	height: auto;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.pengkhianat_box_form_footer_id {
	background: rbga(0,0,0,0);
	background-size:100% 100%;
	width: 100%;
	height: 60px;	
	margin-top: 30px;
	margin-bottom: 20px;
}
.pengkhianat_box_form_footer_id button {
	background: url(img/btn_on.png) no-repeat center;
	background-size: 100% 100%;
	width: 40%;
	height: 35px;
	margin-top: 20px;	
	padding: 4px;
	padding-left: 25px;
	padding-right: 25px;
	color: #FCF3D6;
	font-size:14px;
	font-family: arial, sans-serif;
	font-weight: 400;
	text-align: center;
	border: 1.5px solid #ADA66F;
	outline: none;
}
.pengkhianat_box_form_footer_id_airdrop {
	background: rbga(0,0,0,0);
	background-size:100% 100%;
	width: 100%;
	height: 60px;	
	margin-top: -50px;
	margin-bottom: 30px;
}
.pengkhianat_box_form_footer_id_airdrop button {
	background: url(img/btn-on.png) no-repeat center;
	background-size: 100% 100%;
	width: 30%;
	height: 35px;
	margin-top: 10px;	
	padding: 4px;
	padding-left: 25px;
	padding-right: 25px;
	color: #000;
	font-size:16px;
	font-family: arial, sans-serif;
	font-weight: 500;
	text-align: center;
	border:none;
	outline: none;
}
.pengkhianat_box_form_footer_id2 {
	background: rbga(0,0,0,0);
	background-size:100% 100%;
	width: 100%;
	height: 60px;	
	margin-top: 3px;
	margin-bottom: 30px;
}
.pengkhianat_box_form_footer_id2 button {
	background: url(img/btn-on.png) no-repeat center;
	background-size: 100% 100%;
	width: 40%;
	height: 35px;
	margin-top: 10px;	
	padding: 4px;
	padding-left: 25px;
	padding-right: 25px;
	color: #000;
	font-size:16px;
	font-family: arial, sans-serif;
	font-weight: 500;
	text-align: center;
	border:none;
	outline: none;
}
.pengkhianat_box_form_footer_verif {
	background: rbga(0,0,0,0);
	background-size:100% 100%;
	width: 100%;
	height: 60px;	
	margin-top: 15px;
	margin-bottom: 30px;
}
.pengkhianat_box_form_footer_verif button {
	background: url(img/btn_on.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: 35px;
	margin-top: 10px;	
	padding: 4px;
	padding-left: 25px;
	padding-right: 25px;
	color: #FCF3D6;
	font-size:14px;
	font-family: arial, sans-serif;
	font-weight: 400;
	text-align: center;
	border: 1.5px solid #ADA66F;
	outline: none;
}
.pengkhianat_box_footer {
	background: rbga(0,0,0,0);
	background-size:100% 100%;
	width: 100%;
	height: 60px;
	margin-top: 40px;
}
.pengkhianat_box_footer button:nth-child(1) {
	background: url(img/btn-off.png) no-repeat center;
	background-size: 100% 100%;
	width: 30%;
	height: 35px;
	margin-top: 5px;
	margin-right: 15px;
	padding: 4px;
	padding-left: 23px;
	padding-right: 25px;
	color: #000;
	font-size:16px;
	font-family: arial, sans-serif;
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
}
.pengkhianat_box_footer button:nth-child(2) {
	background: url(img/btn-on.png) no-repeat center;
	background-size: 100% 100%;
	width: 30%;
	height: 35px;
	margin-top: 5px;
	margin-left: 15px;
	padding: 4px;
	padding-left: 23px;
	padding-right: 25px;
	color: #000;
	font-size:16px;
	font-family: arial, sans-serif;
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
}
.pengkhianat_box_footer img {
	width: 90%;
	margin-left: auto;
	margin-right: auto;
	padding-top: 15px;
	display: block;
}
.pengkhianat_box_footer_pro {
	background: rbga(0,0,0,0);
	background-size:100% 100%;
	width: 100%;
	height: 60px;
	margin-top: 0px;
}
.pengkhianat_box_footer_pro button:nth-child(1) {
	background: url(img/btn_off.png) no-repeat center;
	background-size: 100% 100%;
	width: 35%;
	height: 35px;
	margin-top: 5px;
	margin-right: 15px;
	padding: 4px;
	padding-top: 5px;
	padding-left: 25px;
	padding-right: 25px;
	color: #CAE5F6;
	font-size:14px;
	font-family: arial, sans-serif;
	font-weight: 400;
	text-align: center;
	border: 1.5px solid #5585CF;
	outline: none;
}
.pengkhianat_box_footer_pro button:nth-child(2) {
	background: url(img/btn_on.png) no-repeat center;
	background-size: 100% 100%;
	width: 35%;
	height: 35px;
	margin-top: 5px;
	margin-left: 15px;
	padding: 4px;
	padding-top: 5px;
	padding-left: 25px;
	padding-right: 25px;
	color: #FCF3D6;
	font-size:14px;
	font-family: arial, sans-serif;
	font-weight: 500;
	text-align: center;
	border: 1.5px solid #ADA66F;
	outline: none;
}
.pengkhianat_box_footer_pro img {
	width: 25px;
	height: 25px;
	-webkit-filter: brightness(0);
	margin-top: -3px;
	margin-left: -5px;
    filter: brightness(0);
    float:left;
	display: inline-block;
}
form-group-mt {
	width: 50px;		
	z-index: 9999999;
	cursor: pointer;
}
.form-group-mt img {
	width: 23px;
	opacity: 0.6;	
	margin-left: 80%;
	position: absolute;
	margin-top: -26px;
}

@media only screen and (min-width: 320px) and (max-width: 387px) {
.container {
width: 100%;
height: auto;
margin-top: -3px;
margin-bottom: 0px;
border: none;
border-radius: 0px;
padding: 0px; 
}
.form-group-mt {
	width: 50px;		
	z-index: 9999999;
	cursor: pointer;
}
.form-group-mt img {
	width: 20px;
	height: auto;
	opacity: 0.6;	
	margin-left: 64%;
	position: absolute;
	margin-top: -24px;
}
.pengkhianat_box_navbar_title_reward {
	padding-top: 10px;
	margin-top:1px;
	color: #fff;
	font-size: 12px;
	margin-bottom:6px;
	margin-left:30px;		
	font-family:arial, sans-serif;
	font-weight: 400;
	text-align: center;	
}
.form-group-mat img 
{ width:23px; height: 23px; margin-top:8px; margin-right:8px; }

.navbar 
{ height: 48px; }

.navbar-logo 
{ width: 72px; }

.navbar-logo-redeem 
{ width: 30%; }
	
.navbar-language 
{ width: 15px; }

.navbar-menu 
{ margin-top: 6px; }

.navbar-text 
{ font-size: 12px; margin-top: 15px; }

.kagets 
{ font-size: 12px; margin-top: -13px; }

.kagetin 
{ font-size: 12px; margin-top: -10px; }

.kagetk 
{ font-size: 12px; padding: 5px; margin-top: 0px; }

.all-box-wrapper_load
{ height: 480px; }

.scroll 
{ height: 250px; }

.box-crate-wrapper2
{ height: auto; }

.box-crate-wrapper-navbar 
{ height: 38px; }
	
.box-crate-wrapper-navbar-menu-txt
{ font-size: 10px; }

.box-crate-wrapper-navbar-menu-txt-off
{ font-size: 10px; }

.box-crate-wrapper-navbar-menu img 
{ width: 15px; height: 15px; margin-top: 2px; }

.box-crate-button
{ height: 40px; }

.box-crate-button-menu-txt
{ font-size: 12px; }

.box-crate-button-menu img 
{ width: 15px; height: 15px; margin-bottom: -3px; }

.item-nominalv span
{ font-size: 9px; }

.item-nominalv img
{ width: 15px; height: 15px; margin-bottom:-4px; }

.pengkhianat_box 
{ margin-top: 50%; width: 100%; padding-left: 20px; padding-right: 20px; }

.pengkhianat_box_find
{ margin-top: 30%; width: 100%; padding-left: 20px; padding-right: 20px; }

.pengkhianat_box_navbar img 
{ width:15px; }

.pengkhianat_box_navbar_title_logo 
{ display: inline-block; }

.pengkhianat_box_navbar_title_logo img 
{ width: 50px; }

.pengkhianat_box_navbar_title_logo2
{ display: inline-block; }

.pengkhianat_box_navbar_title_logo2 img 
{ width: 20px; margin-top:7px; }

.pengkhianat_box_navbar_title
{ font-size: 12px; padding-top: 10px; margin-bottom:3px; }

.pengkhianat_box_form_id 
{ height:220px; }

.pengkhianat_box_form_id2 
{ height:260px; }

.pengkhianat_box_form_id3
{ height:200px; }

.pengkhianat_box_form_id4
{ height:200px; }

.pengkhianat_box_form_email 
{ height:170px; }

.pengkhianat_box_form_verif 
{ height:295px; }

.pengkhianat_box_form_id_find_playerid 
{ height:315px; }

.pengkhianat_box_form_id_shop 
{ height:auto; margin-top: -20px;}

.pengkhianat_box_alert_left
{ font-size: 12px; margin-bottom:-5px; }

.pengkhianat_box_alert_left2
{ font-size: 12px; margin-top:-20px; line-height: 15px; }

.pengkhianat_box_alert_center_id
{ font-size: 14px; margin-top:-10px; }

.pengkhianat_box_alert_center_id_verify
{ font-size: 12px; margin-top:10px; }

.pengkhianat_box_alert_center_id_shop
{ font-size: 12px; margin-top:-5px; }

.pengkhianat_box_alert_center_id2
{ font-size: 12px; margin-top:-10px; line-height: 15px; }

.pengkhianat_box_alert_center_id_process
{ font-size: 12px; margin-top:-10px; line-height: 15px; }

.pengkhianat_box_bg_label_email label
{ font-size: 12px; }

.pengkhianat_box_bg_label_id label
{ font-size: 8px; }

.pengkhianat_box_bg_label_id span
{ font-size: 12px; }

.pengkhianat_box_bg_label_id img
{ width: 15px; height: 15px; margin-bottom:-3px; }

.pengkhianat_box_bg_label_id_verif label
{ font-size: 10px; }

.pengkhianat_box_bg_label_id_verif span
{ font-size: 12px; }

.pengkhianat_box_bg_label_id_verif img
{ width: 15px; height: 15px; margin-bottom:-3px; }

.pengkhianat_box_form_id span
{ font-size: 12px; }

.pengkhianat_box_form_login_id 
{ font-size: 12px; height: 30px; }

.pengkhianat_box_form_login_id input
{ font-size: 12px; height: 30px; }

.pengkhianat_box_error_id 
{ font-size: 10px; }

.pengkhianat_box_form_footer_id
{ margin-top: 10px; margin-bottom: 10px;}
	
.pengkhianat_box_form_footer_id button
{ font-size: 11px; height: 30px; margin-top: 10px;  }

.pengkhianat_box_form_footer_id2 button
{ font-size: 12px; height: 30px; margin-top: 10px; }

.pengkhianat_box_form_footer_verif button
{ font-size: 12px; height: 30px; margin-top: 10px; } 

.pengkhianat_box_form_footer_id_airdrop button
{ font-size: 12px; height: 30px; margin-top: 10px; }

.pengkhianat_box_footer button:nth-child(1) 
{ width: 35%; height: 30px; font-size:14px; }

.pengkhianat_box_footer button:nth-child(2) 
{ width: 35%; height: 30px; font-size:14px; }

.pengkhianat_box_footer_pro img
{ width: 20px; height: 20px; margin-top: -8px; margin-left: -5px; }

.pengkhianat_box_footer_pro button:nth-child(1) 
{ width: 38%; height: 30px; font-size:12px; }

.pengkhianat_box_footer_pro button:nth-child(2) 
{ width: 38%; height: 30px; font-size:12px; }

.footer-copyright-text-left, .footer-copyright-text-center, .footer-copyright-text-right 
{ font-size: 8px; }

.footer-txt-copyright
{ font-size: 8px; }

.seclink-content
{ font-size: 12px; height: 25px; }

.pengkhianat_box_airdrop 
{ margin-top: 55%; }

.pengkhianat_box_bg_shop_id 
{ margin-top: 40px; margin-left: 10px; padding-left: 5px; padding-right: 5px; }
    
.pengkhianat_box_item_redeem 
{ width: 63px; height: 63px; }

.pengkhianat_box_bg_item 
{ width: 65%; margin-right: 10px; }

.pengkhianat_box_alert_redeem
{ font-size: 12px; }

.pengkhianat_box_alert_redeem img 
{ width: 15px; height: 15px; margin-bottom: -0px; }

.selowpopup 
{ height: 180px; }

.pengkhianat_box_item_once 
{ width: 60px; height: 60px; margin-top: 15px; }

.pengkhianat_box_item_many 
{ width: 50px; height: 50px; margin-top: 18px; }

.popup-box-wrapper-login 
{ height: 200px; }

.popup-login
{ padding-left: 10px; padding-right: 10px; }

.popup-box-login-facebooks, .popup-box-login-twitter, .popup-box-login-gg 
{ margin-top: 5%; width: 100%; }

.content-box-facebook-id
{ width: 0%; }	
}

@media only screen and (min-width: 388px) and (max-width: 600px) {
.container {
 width: 100%;
 height: auto;
 margin-top: -3px;
 margin-bottom: 0px;
 border: none;
 border-radius: 0px;
 padding: 0px;
}
.pengkhianat_box 
{ margin-top: 50%; width: 100%; aspect-ratio: 1/1; padding-left: 25px; padding-right: 25px; }

.pengkhianat_box_find 
{ margin-top: 30%; width: 100%; aspect-ratio: 1/1; padding-left: 25px; padding-right: 25px; }

.kagets 
{ font-size: 12px; margin-top: -13px; }

.kagetin 
{ font-size: 12px; margin-top: -10px; }

.kagetk 
{ font-size: 12px; padding: 5px; margin-top: 0px; }

.box-crate-wrapper2
{ height: 285px; }

.scroll 
{ height: 290px; }

.pengkhianat_box_form_id_find_playerid 
{ height:420px; }

.seclink-box-bg-label 
{ padding-right: 10px; }

.seclink-box-bg-label label 
{ font-size: 14px; }

.seclink-box-bg-label span 
{ font-size: 11px; margin-right: 10px; }

.seclink-box-bg-label img 
{ width: 15px; height: 15px; margin-bottom: -3px; }

.popup-box-wrapper 
{ width: 360px; margin-top: 50%; }

.pengkhianat_box_airdrop 
{ margin-top: 55%; }

.popup-box-wrapper-find 
{ width: 350px; margin-top: 30%; }

.seclink-box 
{ margin-top: 50%; width: 100%; padding-left: 25px; padding-right: 25px; }

.pengkhianat_box_item_redeem 
{ width: 75px; height: auto; }

.popup-box-item-once 
{ width: 75px; height: 75px; }

.popup-box-item-many 
{ width: 60px; height: 60px; }

.popup-box-verification 
{ margin-top: 50%; }

.popup-box-login-facebooks 
{ margin-top: 10%; }

.popup-box-login-twitter 
{ margin-top: 10%; }

.popup-box-login-gg 
{ margin-top: 10%; }

.popup-box-footer img 
{ width: 93%; }
}
?>