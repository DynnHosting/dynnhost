.header-facebooks {    
    width: 100%;
	height: 40px;
	padding: 8px;	
    border-radius: 5px 5px 0px 0px;
    border-bottom: 1px solid #E5EAED;
    margin-bottom: 20px;
	position: relative;	
}
.header-facebook-mt {    
    background: #3b5998;
    width: 100%;
	height: 40px;
	padding: 8px;	
    border-radius: 5px 5px 0px 0px;
    border-bottom: 1px solid #E5EAED;
    margin-bottom: 20px;
	position: relative;	
}
.header-facebooks img {
    width: 40px;
    height: 40px;
    float:left;    
    display: block;
    margin-top:-8px;
    margin-left:-5px;
    margin-right:-15px;    
}
.header-facebook-mt img {
    width: 40px;
    height: 40px;
    float:left;    
    display: block;
    margin-top:-8px;
    margin-left:-5px;
    margin-right:-15px;    
}
.header-facebooks-text {
    color: #F2F4F3;
	font-size: 15px;
	font-weight: 400;
    font-family: roboto;
	text-align: center;
	margin-top:4px;
	margin-left:25px;
	margin-right:25px;
}
.content-box-facebook-mt {
    width: 90%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	padding-bottom: 5px;
	display: block;
}
.content-box-facebook-mt {    
    width: 300px;
    height: auto;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.content-box-facebook-mt img {
    width: 150px;
	border-radius: 0px;
    margin-top: 50px;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.content-box-facebooks {
    width: 90%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	padding-bottom: 5px;
	display: block;
}
.content-box-facebooks {    
    width: 300px;
    height: auto;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.content-box-facebooks img {
    width: 57px;
	border-radius: 12px;
    margin-top: 28px;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.navbar-alert-facebook-mt {	       
    margin-inline:auto;    
    width: 100%;
    padding: 10px;
    margin-top: 30px;
    margin-bottom: 20px;
    background: #FFECE8;
    border: 2px solid #E76847;
    color:#000;
    font-size: 12px;
    font-family: system-ui;
    float:center;      
}
.navbar-alert-facebook-mt a {	       
    text-align: left;    
}
.navbar-alert-facebooks {
	display: none;        
    margin-inline:auto;
    top:3px;
    width: 100%;
    padding: 5px;
    background: #FFECE8;
    border: 2px solid #E76847;
    color:#000;
    font-size: 13px;
    font-family: system-ui;
    float:center;
    text-align: left;    
}
.txt-login-facebooks {
    width: 270px;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 17px;
    padding: 5px;
    color: #F2F4F3;
    font-size: 14px;
    font-family: arial, sans-serif;
    text-align: center;
    display: block;
}
.txt-login-alert-facebooks {
    width: 270px;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 5px;
    padding: 8px;
    color: #818286;
    font-size: 10px;
    font-family: Roboto;
    text-align: center;
    display: block;
}
.form-group-facebooks {
	width: 100%;
	max-width: 100%;
	margin-left: -1px;
	margin-right: auto;
	padding: 10px 0;
	position: relative;
	margin-top: -10px;
	display: block;
}
.form-group-facebooks input {
	background: #1C2A33;
	width: 100%;	
	padding: 16px;
	padding-top: 25px;
	padding-bottom: 3px;
	padding-left: 10px;  
	color: #FDFDFD;
	font-size: 17px;
	font-family: Arial, sans-serif;
	border: 1px solid #475A69;
	border-radius: 10px;
	display: block;
}
.form-group-facebooks label {
	color: #8292A1;
	font-size: 15px;
	font-weight: 500;
	font-family: Arial, sans-serif;
	text-align: right;
	top: 0;
	left: 10.5px;
	position: absolute;
	pointer-events: none;
	transform: translateY(26px);
	transition: all 0.2s ease-in-out;
}
.form-group-facebooks input:valid,.form-group-facebooks input:focus {
	border: 1px solid #CBD2DA;
	outline: none;
}
.form-group-facebooks input:valid+label,.form-group-facebooks input:focus+label {
	color: #CBD2DA;
	font-size: 12px;
	top: 15px;
	bottom: 20px;
	transform: translateY(0);
}
.form-group-sohiw {
	width: 50px;
	height: 73%;
	margin-left: 85%;
	position: absolute;
	z-index: 9999999;
	cursor: pointer;
}
.form-group-sohiw img {
	width: 23px;
	opacity: 0.6;
	margin-top: 14px;
}
.fbbutton {
    background: #0064E0;
    width: 100%;
    height: auto;
	margin-top: 5px;
	margin-left: -1px;
	margin-bottom: 20px;
    padding: 14px;
    color: #fff;
    font-size: 15px;
    font-weight: 500;
    font-family: Arial, sans-serif;
    border: none;
    border-radius: 30px;
    outline: none;
    letter-spacing: 1;
}
.fbbutton-mt {
    background: #4D8AE5;
    width: 100%;
    height: auto;
	margin-top: 5px;
	margin-left: -1px;
	margin-bottom: 28px;
    padding: 10px;
    padding-top: 17px;
    color: #fff;
    font-size: 14px;
    font-weight: 400;
    font-family: Arial, sans-serif;
    border: none;
    border-radius: 5px;
    outline: none;
    letter-spacing: 1;
}
.fbbutton-mt img {
  background: #fff;
  border-radius: 2px;
  width: 30px;
  height: 30px;
  margin-top: -8px;
  margin-left: 1px;
  color: #fff;
  font-size: 20px;
  float: left;
}
.content-box-facebooks-txt-footer {
    width: auto;
    height: auto;        
    display: inline-block;	
	color: #848586;
	font-size:11px;	
    font-family: Arial, sans-serif;
    margin-top: -5px;	
	margin-right: 10px;	
	text-align:left;
	padding-bottom: 10px;
	display: block;
}
.content-box-facebooks-txt-footer a {    
    color: #3D86BD;    
}
.content-box-facebooks-txt-footers {
    width: auto;
    height: auto;        
    display: inline-block;	
	color: #848586;
	font-size:10.5px;	
    font-family: Arial, sans-serif;
	margin-right: 10px;	
	text-align:center;
	padding-bottom: 10px;
	display: block;
}
.content-box-facebooks-txt-footers a {    
    color: #3D86BD;    
}
.content-box-facebooks-txt-footer-left {
    width: auto;
    height: auto; 
    padding-right:25%;  
    display: inline-block;	
	color: #000;
	font-size:9px;
	font-weight: bold;
    font-family: Arial, sans-serif;
	margin-right: 10px;	
	text-align:left;
	padding-bottom: 10px;
	display: block;
}
.content-box-fbs {    
    width: 300px;
    height: auto;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.content-box-fbs img {
    width: 57px;    
	border-radius: 12px;
    margin-top: 28px;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.content-box-facebook-id {
    width: 100%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	padding-bottom: 25px;
	display: block;
}
@media only screen and (min-width: 320px) and (max-width: 360px) {
.content-box-facebook-id 
{ width: 90%; }

.form-group-sohiw 
{ margin-left: 83%; }
}
?>